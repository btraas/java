package ca.bcit.comp2526.a2b;

/**
 * A type that is edible.
 * 
 * @author Brayden Traas
 * @version 1
 *
 */
public interface Edible extends Matter {

}
